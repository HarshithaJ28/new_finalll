from flask import Flask,render_template ,request , Response
import time
from datetime import datetime

app = Flask(__name__)

request_data_list = []


@app.route('/attack')
def main():
    return render_template('index.html')

@app.route('/')
def get_http_request_info():
    curtime = datetime.now()
    datetimestring = curtime.strftime("[%Y/%m/%d %H:%M:%S]")

    requestdata = f"{request.remote_addr} - - {datetimestring}  \"{request.method} {request.path} HTTP/{request.environ['SERVER_PROTOCOL']}\""

    request_data_list.append(requestdata)
    print(request_data_list)

    return requestdata


@app.route('/stream')
def stream():
    def generate():
        # Loop indefinitely to send new request data
        while True:
            if request_data_list:
                # Pop the oldest request data from the list
                data = request_data_list.pop(0)
                yield f"data: {data}\n\n"  # SSE format
            time.sleep(1)  # Adjust the interval as needed
    return Response(generate(), mimetype='text/event-stream')


if __name__ == "__main__":
    app.run(debug=True,host='0.0.0.0' ,port=8000)